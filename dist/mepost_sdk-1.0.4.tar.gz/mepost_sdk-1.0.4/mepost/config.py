class MepostConfig:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.mepost.io/v1"
